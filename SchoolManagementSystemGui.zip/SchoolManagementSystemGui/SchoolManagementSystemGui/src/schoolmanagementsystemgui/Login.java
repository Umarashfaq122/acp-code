package schoolmanagementsystemgui;

import javax.swing.*;
import java.awt.*;
import java.util.HashMap;

public class Login extends JFrame {

    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton, registerButton;
    private JLabel usernameLabel, passwordLabel, titleLabel;

    // Data structure to store registered users
    private static final HashMap<String, String> userDatabase = new HashMap<>();

    // Preload a default admin account
    static {
        userDatabase.put("admin", "1234");
    }

    public Login() {
        setTitle("Login - School Management System");
        setSize(450, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        // Title label
        titleLabel = new JLabel("School Management System Login", JLabel.CENTER);
        titleLabel.setFont(new Font("Tahoma", Font.BOLD, 24));
        titleLabel.setForeground(new Color(60, 60, 255));

        // Form labels and fields
        usernameLabel = new JLabel("Username:");
        usernameLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
        passwordLabel = new JLabel("Password:");
        passwordLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));

        usernameField = new JTextField(20);
        passwordField = new JPasswordField(20);

        // Set preferred sizes for text fields
        usernameField.setPreferredSize(new Dimension(300, 40));
        passwordField.setPreferredSize(new Dimension(300, 40));

        // Style text fields
        usernameField.setFont(new Font("Tahoma", Font.PLAIN, 14));
        passwordField.setFont(new Font("Tahoma", Font.PLAIN, 14));

        // Buttons
        loginButton = new JButton("Login");
        registerButton = new JButton("Register");

        // Button actions
        loginButton.addActionListener(e -> {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());
            if (authenticateUser(username, password)) {
                JOptionPane.showMessageDialog(null, "Login Successful!", "Welcome", JOptionPane.INFORMATION_MESSAGE);
                dispose(); // Close the Login frame
                new SchoolManagementSystemGUI(); // Open the main system GUI
            } else {
                JOptionPane.showMessageDialog(null, "Invalid username or password", "Login Failed", JOptionPane.ERROR_MESSAGE);
            }
        });

        registerButton.addActionListener(e -> {
            String username = JOptionPane.showInputDialog(this, "Enter new username:", "Register", JOptionPane.PLAIN_MESSAGE);
            if (username == null || username.trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Username cannot be empty!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            String password = JOptionPane.showInputDialog(this, "Enter new password:", "Register", JOptionPane.PLAIN_MESSAGE);
            if (password == null || password.trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Password cannot be empty!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (userDatabase.containsKey(username)) {
                JOptionPane.showMessageDialog(this, "Username already exists!", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                userDatabase.put(username, password);
                JOptionPane.showMessageDialog(this, "Registration successful! You can now log in.", "Success", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        // Layout settings
        setLayout(new BorderLayout(10, 10));

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        // Title label centered at the top
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        panel.add(titleLabel, gbc);

        // Username label and field
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.EAST;
        panel.add(usernameLabel, gbc);

        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        panel.add(usernameField, gbc);

        // Password label and field
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.anchor = GridBagConstraints.EAST;
        panel.add(passwordLabel, gbc);

        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        panel.add(passwordField, gbc);

        // Login button
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        panel.add(loginButton, gbc);

        // Register button
        gbc.gridy = 4;
        panel.add(registerButton, gbc);

        // Add the panel to the frame's center
        add(panel, BorderLayout.CENTER);

        setVisible(true);
    }

    // Method for user authentication
    private boolean authenticateUser(String username, String password) {
        return userDatabase.containsKey(username) && userDatabase.get(username).equals(password);
    }

    // Main method to start the application
    public static void main(String[] args) {
        SwingUtilities.invokeLater(Login::new);
    }
}
