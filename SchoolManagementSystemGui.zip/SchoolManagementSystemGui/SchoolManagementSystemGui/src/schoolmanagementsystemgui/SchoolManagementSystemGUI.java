package schoolmanagementsystemgui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class SchoolManagementSystemGUI {

    private List<Student> students;

    private JFrame frame;
    private JTextArea textArea;
    private JTextField idField, nameField, ageField, fatherNameField, subjectField;
    private JButton addButton, removeButton, viewButton, searchByIdButton, searchByNameButton, clearButton, exitButton;

    public SchoolManagementSystemGUI() {
        students = new ArrayList<>();
        createAndShowGUI();
    }

    private void createAndShowGUI() {
        frame = new JFrame("School Management System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(700, 600);
        frame.setLayout(new BorderLayout());

        JLabel welcomeLabel = new JLabel("Welcome to Student Enrollment System", JLabel.CENTER);
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 20));
        welcomeLabel.setBackground(Color.CYAN);
        welcomeLabel.setOpaque(true);
        frame.add(welcomeLabel, BorderLayout.NORTH);

        JPanel panel = new JPanel();
        panel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.WEST;

        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(new JLabel("Student ID:"), gbc);

        gbc.gridx = 1;
        idField = new JTextField(20);
        panel.add(idField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(new JLabel("Student Name:"), gbc);

        gbc.gridx = 1;
        nameField = new JTextField(20);
        panel.add(nameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(new JLabel("Student Age:"), gbc);

        gbc.gridx = 1;
        ageField = new JTextField(20);
        panel.add(ageField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        panel.add(new JLabel("Father's Name:"), gbc);

        gbc.gridx = 1;
        fatherNameField = new JTextField(20);
        panel.add(fatherNameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        panel.add(new JLabel("Subject:"), gbc);

        gbc.gridx = 1;
        subjectField = new JTextField(20);
        panel.add(subjectField, gbc);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        addButton = new JButton("Add Student");
        removeButton = new JButton("Remove Student");
        viewButton = new JButton("View All Students");
        searchByIdButton = new JButton("Search by ID");
        searchByNameButton = new JButton("Search by Name");
        clearButton = new JButton("Clear All Students");
        exitButton = new JButton("Exit");

        buttonPanel.add(addButton);
        buttonPanel.add(removeButton);
        buttonPanel.add(viewButton);
        buttonPanel.add(searchByIdButton);
        buttonPanel.add(searchByNameButton);
        buttonPanel.add(clearButton);
        buttonPanel.add(exitButton);

        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.add(panel, BorderLayout.CENTER);
        topPanel.add(buttonPanel, BorderLayout.SOUTH);
        frame.add(topPanel, BorderLayout.CENTER);

        textArea = new JTextArea();
        textArea.setEditable(false);
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(650, 200));
        frame.add(scrollPane, BorderLayout.SOUTH);

        addButton.addActionListener(new AddStudentActionListener());
        removeButton.addActionListener(new RemoveStudentActionListener());
        viewButton.addActionListener(new ViewAllStudentsActionListener());
        searchByIdButton.addActionListener(new SearchStudentByIdActionListener());
        searchByNameButton.addActionListener(new SearchStudentByNameActionListener());
        clearButton.addActionListener(new ClearStudentsActionListener());
        exitButton.addActionListener(e -> System.exit(0));

        frame.setVisible(true);
    }

    private void updateTextArea(String text) {
        textArea.setText(text);
    }

    private class AddStudentActionListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            try {
                int id = Integer.parseInt(idField.getText());
                String name = nameField.getText();
                int age = Integer.parseInt(ageField.getText());
                String fatherName = fatherNameField.getText();
                String subject = subjectField.getText();
                Student student = new Student(id, name, age, fatherName, subject);
                students.add(student);
                updateTextArea("Student added: " + name);
            } catch (NumberFormatException ex) {
                updateTextArea("Invalid input. Please enter valid student details.");
            }
        }
    }

    private class RemoveStudentActionListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            try {
                int id = Integer.parseInt(idField.getText());
                students.removeIf(student -> student.getId() == id);
                updateTextArea("Student removed with ID: " + id);
            } catch (NumberFormatException ex) {
                updateTextArea("Please enter a valid student ID.");
            }
        }
    }

    private class ViewAllStudentsActionListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            if (students.isEmpty()) {
                updateTextArea("No students found.");
            } else {
                StringBuilder sb = new StringBuilder();
                for (Student student : students) {
                    sb.append("ID: ").append(student.getId())
                            .append(", Name: ").append(student.getName())
                            .append(", Age: ").append(student.getAge())
                            .append(", Father's Name: ").append(student.getFatherName())
                            .append(", Subject: ").append(student.getSubject()).append("\n");
                }
                updateTextArea(sb.toString());
            }
        }
    }

    private class SearchStudentByIdActionListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            try {
                int id = Integer.parseInt(idField.getText());
                Student student = students.stream().filter(s -> s.getId() == id).findFirst().orElse(null);
                if (student != null) {
                    updateTextArea("Found student: " + student.getName() + " (ID: " + student.getId() + ")");
                } else {
                    updateTextArea("No student found with ID: " + id);
                }
            } catch (NumberFormatException ex) {
                updateTextArea("Please enter a valid student ID.");
            }
        }
    }

    private class SearchStudentByNameActionListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            String name = nameField.getText();
            Student student = students.stream().filter(s -> s.getName().equalsIgnoreCase(name)).findFirst().orElse(null);
            if (student != null) {
                updateTextArea("Found student: " + student.getName() + " (ID: " + student.getId() + ")");
            } else {
                updateTextArea("No student found with name: " + name);
            }
        }
    }

    private class ClearStudentsActionListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            int confirmed = JOptionPane.showConfirmDialog(frame, "Are you sure you want to clear all students?", "Clear All Students", JOptionPane.YES_NO_OPTION);
            if (confirmed == JOptionPane.YES_OPTION) {
                students.clear();
                updateTextArea("All students cleared.");
            }
        }
    }

    static class Student {
        private int id;
        private String name;
        private int age;
        private String fatherName;
        private String subject;

        public Student(int id, String name, int age, String fatherName, String subject) {
            this.id = id;
            this.name = name;
            this.age = age;
            this.fatherName = fatherName;
            this.subject = subject;
        }

        public int getId() {
            return id;
        }

        public String getName() {
            return name;
        }

        public int getAge() {
            return age;
        }

        public String getFatherName() {
            return fatherName;
        }

        public String getSubject() {
            return subject;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(SchoolManagementSystemGUI::new);
    }
}